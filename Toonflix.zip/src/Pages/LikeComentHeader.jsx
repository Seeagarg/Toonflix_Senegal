import React from 'react'

const LikeComentHeader = () => {
  return (
    <div>LikeComentHeader</div>
  )
}

export default LikeComentHeader