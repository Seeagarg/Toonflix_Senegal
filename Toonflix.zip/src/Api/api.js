// const baseurl =`https://www.demo-new.toon-flix.com/`
// const baseurl ='http://localhost:6012/'
// const baseurl = '/'
// const baseurl ='https://kentelkom.toon-flix.com/'

// const baseurl =`https://www.demo-new.toon-flix.com/`

export const base_url_toonflix = 'https://backendos.toon-flix.com'

const baseurl ='/'
// const baseurl = 'http://localhost:6012/'
export {baseurl}

const HomeApi =`${baseurl}api/content/little`
export {HomeApi}
const CommentPostApi =`${baseurl}api/little`
export {CommentPostApi}
 const CommentGETApi =`${baseurl}little/comments`
 export {CommentGETApi}