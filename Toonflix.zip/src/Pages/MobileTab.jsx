const [showPopup, setShowPopup] = useState(true);

const handleClose = () => {
  setShowPopup(false);
};